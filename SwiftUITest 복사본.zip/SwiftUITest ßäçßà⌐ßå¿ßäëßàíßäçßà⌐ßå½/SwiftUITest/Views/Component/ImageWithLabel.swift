//
//  ImageWithLabel.swift
//  SwiftUITest
//
//  Created by 윤범태 on 2023/11/29.
//

import SwiftUI

struct ImageWithLabel: View {
    let imageName, name: String
    
    var body: some View {
        VStack(alignment: .leading) {
            Image(imageName)
            Text(name)
                .foregroundStyle(.black)
        }
    }
}

#Preview {
    ImageWithLabel(imageName: "icybay", name: "Icybay")
}
