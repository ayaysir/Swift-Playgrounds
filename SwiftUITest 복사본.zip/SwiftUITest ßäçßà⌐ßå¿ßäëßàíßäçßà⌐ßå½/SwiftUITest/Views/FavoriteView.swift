//
//  FavoriteView.swift
//  SwiftUITest
//
//  Created by 윤범태 on 2023/11/29.
//

import SwiftUI

struct FavoriteView: View {
    @Environment(ModelData.self) private var modelData
    
    var body: some View {
        NavigationStack {
            List {
                ForEach(modelData.landmarks.filter({ $0.isFavorite })) { favorite in
                    NavigationLink {
                        DetailView(landmark: favorite)
                    } label: {
                        Image(favorite.imageName)
                    }

                }
            }
            .navigationTitle("Favorites")
            .navigationBarTitleDisplayMode(.large)
        }
    }
}

#Preview {
    FavoriteView()
        .environment(ModelData())
}
