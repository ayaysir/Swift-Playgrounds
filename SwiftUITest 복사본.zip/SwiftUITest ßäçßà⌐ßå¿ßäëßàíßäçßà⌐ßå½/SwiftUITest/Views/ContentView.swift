//
//  ContentView.swift
//  SwiftUITest
//
//  Created by LeeMinJi on 2023/10/30.
//

import SwiftUI

struct ContentView: View {
    @State private var modelData = ModelData()
    
    var body: some View {
        TabView {
            ListView()
                .tabItem {
                    Image(systemName: "list.bullet")
                    Text("List")
                }
                .environment(modelData)
            FavoriteView()
                .tabItem {
                    Image(systemName: "star.fill")
                    Text("Favorites")
                }
                .environment(modelData)
        }
    }
}

#Preview {
    ContentView()
}
