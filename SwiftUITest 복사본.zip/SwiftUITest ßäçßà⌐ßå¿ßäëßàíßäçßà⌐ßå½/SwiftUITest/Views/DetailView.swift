//
//  DetailView.swift
//  SwiftUITest
//
//  Created by 윤범태 on 2023/11/29.
//

import SwiftUI

struct DetailView: View {
    @State var landmark: Landmark
    
    var body: some View {
        NavigationStack {
            VStack {
                Image(landmark.imageName)
                    .resizable()
                    .scaledToFill()
                    .frame(height: 200)
                List {
                    Section("Information") {
                        Label(landmark.park, systemImage: "play")
                        Label(landmark.state, systemImage: "mappin.and.ellipse")
                    }
                    
                    Section("Description") {
                        Text(landmark.description)
                    }
                }
            }
            .navigationTitle("Salmon ")
            .navigationBarTitleDisplayMode(.inline)
            .scrollIndicators(.never)
        }
        
    }
}

// #Preview {
//     DetailView()
// }
