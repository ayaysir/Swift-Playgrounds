//
//  ListView.swift
//  SwiftUITest
//
//  Created by 윤범태 on 2023/11/29.
//

import SwiftUI

struct ListView: View {
    @Environment(ModelData.self) private var modelData
    
    var body: some View {
        NavigationStack {
            List {
                ForEach(Category.allCases, id: \.self) { type in
                    VStack(alignment: .leading) {
                        Text(type.rawValue)
                            .font(.title2)
                        ScrollView(.horizontal) {
                            HStack {
                                if let landmarks = modelData.categories[type.rawValue] {
                                    ForEach(landmarks) { landmark in
                                        NavigationLink {
                                            DetailView(landmark: landmark)
                                        } label: {
                                            ImageWithLabel(imageName: landmark.imageName, name: landmark.name)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            .scrollIndicators(.never)
            .navigationTitle("Landmarks")
            .listStyle(.plain)
        }
        .onAppear {
            // print(modelData.categories)
        }
    }
}

#Preview {
    ListView()
        .environment(ModelData())
}
