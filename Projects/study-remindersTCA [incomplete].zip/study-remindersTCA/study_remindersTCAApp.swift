//
//  study_remindersTCAApp.swift
//  study-remindersTCA
//
//  Created by 윤범태 on 6/25/25.
//

import App
import AppCore
import RemindersList
import SwiftUI

@main
public struct study_remindersTCAApp: App {
  public var body: some Scene {
    WindowGroup {
      AppView()
    }
  }
  
  public init() {
    
  }
}
