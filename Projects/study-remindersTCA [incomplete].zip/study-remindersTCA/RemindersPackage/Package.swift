// swift-tools-version: 6.1
// The swift-tools-version declares the minimum version of Swift required to build this package.

import PackageDescription

let package = Package(
  name: "RemindersPackage",
  platforms: [
    .iOS(.v16),
    .watchOS(.v8)
  ],
  products: [
    // Products define the executables and libraries a package produces, making them visible to other packages.
    // 이 패키지는 "App"이라는 이름의 라이브러리 제품을 만듭니다.
    // 이 라이브러리는 "App"이라는 **타깃(target)**의 빌드 결과로 구성됩니다.
    // - (Target: 패키지 내의 코드 집합, App 타깃은 Sources/App 폴더에 있는 Swift 파일들을 포함)
    // 실제 코드는 타깃 단위로 작성되고, products는 그것을 외부에 공개할지 여부를 결정합니다.
    // 다른 모듈이나 패키지에서 import App으로 사용할 수 있습니다.
    .library(name: "App", targets: ["App"]),
    .library(name: "AppCore", targets: ["AppCore"]),
    
    .library(name: "AppDelegateCore", targets: ["AppDelegateCore"]),
    
    .library(name: "NotificationCenterClient", targets: ["NotificationCenterClient"]),
    .library(name: "NotificationCenterClientLive", targets: ["NotificationCenterClientLive"]),
    
    .library(name: "ReminderDetailCore", targets: ["ReminderDetailCore"]),
    .library(name: "ReminderDetail", targets: ["ReminderDetail"]),
    
    .library(name: "RemindersListCore", targets: ["RemindersListCore"]),
    .library(name: "RemindersList", targets: ["RemindersList"]),
    
    .library(name: "RemindersListRowCore", targets: ["RemindersListRowCore"]),
    .library(name: "RemindersListRow", targets: ["RemindersListRow"]),
    
    .library(name: "SharedModels", targets: ["SharedModels"]),
    
    .library(name: "UIApplicationClient", targets: ["UIApplicationClient"]),
    .library(name: "UIApplicationClientLive", targets: ["UIApplicationClientLive"]),
    
    .library(name: "UserNotificationClient", targets: ["UserNotificationClient"]),
    .library(name: "UserNotificationClientLive", targets: ["UserNotificationClientLive"]),
    
    .library(name: "WatchOSApp", targets: ["WatchOSApp"]),
    
    .library(name: "WatchRemindersListRow", targets: ["WatchRemindersListRow"]),
  ],
  dependencies: [
    .package(url: "https://github.com/pointfreeco/swift-composable-architecture.git", from: "1.20.2")
  ],
  targets: [
    // Targets are the basic building blocks of a package, defining a module or a test suite.
    // Targets can depend on other targets in this package and products from dependencies.
    .target(name: "AppCore",
            dependencies: [ // 이 타깃이 의존하는 다른 모듈들입니다.
              // 외부 패키지인 TCA에서 제공하는 "ComposableArchitecture" 모듈에 의존
              // import ComposableArchitecture
              .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
              // Sources/AppDelegateCore/와 Sources/RemindersListCore/ 디렉터리가 존재
              // 해당 모듈들을 먼저 빌드한 뒤 AppCore에서 사용할 수 있다는 의미
              "AppDelegateCore",
              "RemindersListCore"
                          ]
           ),
    .target(
      name: "App",
      dependencies: [
        "AppCore",
        "NotificationCenterClientLive",
        "RemindersList",
        "UIApplicationClientLive",
        "UserNotificationClientLive"
      ]
    ),
    
    .target(
      name: "AppDelegateCore",
      dependencies: [
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        "UserNotificationClient"
      ]
    ),
  
    .target(
      name: "NotificationCenterClient",
      dependencies: [
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture")
      ]
    ),
    .target(
      name: "NotificationCenterClientLive",
      dependencies: ["NotificationCenterClient"]
    ),
    
    .target(
      name: "ReminderDetailCore",
      dependencies: [
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        "NotificationCenterClient",
        "SharedModels",
        "UIApplicationClient",
        "UserNotificationClient"
      ]
    ),
    .testTarget(
      name: "ReminderDetailCoreTests",
      dependencies: ["ReminderDetailCore"]
    ),
    .target(
      name: "ReminderDetail",
      dependencies: ["ReminderDetailCore"]
    ),
    
    .target(
      name: "RemindersListCore",
      dependencies: [
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        "SharedModels",
        "ReminderDetailCore",
        "RemindersListRowCore"
      ]
    ),
    .testTarget(
      name: "RemindersListCoreTests",
      dependencies: ["RemindersListCore"]
    ),
    .target(
      name: "RemindersList",
      dependencies: ["ReminderDetail", "RemindersListCore", "RemindersListRow"]
    ),
    
    .target(
      name: "RemindersListRowCore",
      dependencies: [
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        "SharedModels",
        "UserNotificationClient"
      ]
    ),
    .testTarget(
      name: "RemindersListRowCoreTests",
      dependencies: ["RemindersListRowCore"]
    ),
    .target(
      name: "RemindersListRow",
      dependencies: ["RemindersListRowCore"]
    ),
    
    .target(
      name: "SharedModels",
      dependencies: []
    ),
  
    .target(
      name: "UIApplicationClient",
      dependencies: [
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture")
      ]
    ),
    .target(
      name: "UIApplicationClientLive",
      dependencies: ["UIApplicationClient"]
    ),
    
    .target(
      name: "UserNotificationClient",
      dependencies: [
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture")
      ]
    ),
    .target(
      name: "UserNotificationClientLive",
      dependencies: ["UserNotificationClient"]
    ),
    
    .target(name: "WatchOSApp", dependencies: [
      "AppCore",
      "WatchRemindersListRow",
      "UserNotificationClientLive"
    ]),
  
    .target(name: "WatchRemindersListRow", dependencies: ["RemindersListRowCore"])
  ]
)
