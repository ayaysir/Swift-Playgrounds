#!/bin/bash

# 모듈 이름 리스트
modules=(
  App
  AppCore
  AppDelegateCore
  NotificationCenterClient
  NotificationCenterClientLive
  ReminderDetailCore
  ReminderDetail
  RemindersListCore
  RemindersList
  RemindersListRowCore
  RemindersListRow
  SharedModels
  UIApplicationClient
  UIApplicationClientLive
  UserNotificationClient
  UserNotificationClientLive
  WatchOSApp
  WatchRemindersListRow
)

# Sources 디렉토리 만들기 (없으면)
mkdir -p Sources

# 각 모듈 폴더 생성
for module in "${modules[@]}"; do
  mkdir -p "Sources/$module"
  echo "Created Sources/$module"
done
