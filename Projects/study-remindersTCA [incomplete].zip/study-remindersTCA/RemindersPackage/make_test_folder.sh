#!/bin/bash

# 테스트 타깃 이름 배열
test_targets=(
  ReminderDetailCoreTests
  RemindersListCoreTests
  RemindersListRowCoreTests
)

# Tests 디렉토리 만들기
mkdir -p Tests

# 각 테스트 타깃 폴더 생성
for target in "${test_targets[@]}"; do
  mkdir -p "Tests/$target"
  echo "Created Tests/$target"
done
