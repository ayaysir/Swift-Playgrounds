import ComposableArchitecture
import NotificationCenterClient
import ReminderDetailCore
import RemindersListRowCore
import SharedModels
import UIApplicationClient
import UserNotificationClient

public struct ReminderListDomain {
  public init() {}
  
  public struct State: Equatable {
    public var name: String = ""
    
    public init() {}
  }
  
  public enum Action: Equatable, BindableAction {
    case binding(BindingAction<State>)
  }
  
  public var body: some ReducerOf<Self> {
    BindingReducer()
    // + 기타 Reducer들
  }
}
