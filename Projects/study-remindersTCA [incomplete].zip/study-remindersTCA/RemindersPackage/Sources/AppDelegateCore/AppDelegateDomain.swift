import ComposableArchitecture

@Reducer
public struct AppDelegateDomain {
  public init() {
    
  }
}
