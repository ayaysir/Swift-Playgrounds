import ComposableArchitecture

// internal로 변환되어서 사용불가
// @Reducer
// public struct AppDomain {
//   public init() {
//     
//   }
//   
//   @ObservableState
//   public struct State: Equatable {
//     public init() {}
//   }
//   
//   public enum Action: Equatable {
//     
//   }
//   
//   // Reducer
// }

public struct AppDomain: Reducer {
  public init() {}
  
  public struct State: Equatable {
    public var name: String = ""
    
    public init() {}
  }
  
  public enum Action: Equatable, BindableAction {
    case binding(BindingAction<State>)
  }
  
  public var body: some ReducerOf<Self> {
    BindingReducer()
    // + 기타 Reducer들
  }
}

public typealias StoreOfAppDomain = StoreOf<AppDomain>
