//
//  AppView.swift
//  RemindersPackage
//
//  Created by 윤범태 on 6/25/25.
//

import AppCore // State/Action Domain
import ComposableArchitecture
import SwiftUI

public struct AppView: View {
  @Perception.Bindable var store: StoreOf<AppDomain>
  public var body: some View {
    WithPerceptionTracking {
      Text("Hello, World!")
    }
  }
  
  public init() {
    self.store = Store(
      initialState: AppDomain.State(), // 'AppDomain.State' initializer is inaccessible due to 'internal' protection level
      reducer: { AppDomain() } // 'AppDomain' initializer is inaccessible due to 'internal' protection level
    )
  }
}

#Preview {
  AppView()
}
