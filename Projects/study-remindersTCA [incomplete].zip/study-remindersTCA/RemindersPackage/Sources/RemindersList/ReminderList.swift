import ComposableArchitecture
import ReminderDetail
import RemindersListRow
import RemindersListCore
import SharedModels
import SwiftUI

public struct RemindersList: View {
  let store: StoreOf<RemindListDomain>
  
  public var body: some View {
    Text("abc")
  }
}
